export default {
  navigationBarTitleText: '国标治理'
}
