export default {
  navigationBarTitleText: '用户中心'
}
