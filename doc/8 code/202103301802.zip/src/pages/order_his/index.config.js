export default {
  navigationBarTitleText: '我的订单'
}
