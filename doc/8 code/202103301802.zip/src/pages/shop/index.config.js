export default {
  navigationBarTitleText: '商店'
}
