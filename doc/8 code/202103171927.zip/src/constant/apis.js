export const API_SERVER     = 'http://localhost'

export const getLatestTopic = '/getLatestTopic'
