export default {
  navigationBarTitleText: '服务案例'
}
