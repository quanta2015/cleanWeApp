export default {
  navigationBarTitleText: '购物车'
}
