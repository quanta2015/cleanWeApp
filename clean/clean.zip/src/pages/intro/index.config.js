export default {
  navigationBarTitleText: '公司简介'
}
