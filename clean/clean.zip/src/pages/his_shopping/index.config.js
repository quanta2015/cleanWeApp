export default {
  navigationBarTitleText: '我的购物'
}
