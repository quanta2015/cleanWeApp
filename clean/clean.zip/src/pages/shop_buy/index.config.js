export default {
  navigationBarTitleText: '立即支付'
}
