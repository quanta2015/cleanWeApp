export default {
  navigationBarTitleText: '分享除醛'
}
