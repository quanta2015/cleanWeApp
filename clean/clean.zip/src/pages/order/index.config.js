export default {
  navigationBarTitleText: '预约服务',
  enableShareTimeline: true,
}
