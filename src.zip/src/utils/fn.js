
export const randomTime =(min,max)=>{
  return Math.floor(Math.random()*(max-min+1)+min)
}


// export const function delay(t, val) {
//    return new Promise(function(resolve) {
//        setTimeout(function() {
//            resolve(val);
//        }, t);
//    });
// }