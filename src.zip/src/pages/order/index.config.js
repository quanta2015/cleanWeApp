export default {
  navigationBarTitleText: '预约服务'
}
